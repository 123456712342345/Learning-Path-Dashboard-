const express = require('express');
const session = require('express-session');
const mysql = require('mysql2/promise');
const app = express();

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));

app.use(session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: false
}));

// MySQL connection
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '9573475561',
    database: 'Learning_Path_Dashboard',
});

// Routes
app.get('/', (req, res) => res.redirect('/login'));

app.get('/login', (req, res) => res.render('login'));


app.get('/register', (req, res) => res.render('register'));

// Handle register
app.post('/register', async (req, res) => {
    const { name, email } = req.body;
    try {
        // 1. Count existing rows
        const [rows] = await pool.query('SELECT COUNT(*) AS count FROM User');
        const count = rows[0].count;

        // 2. Set new user_id
        const newUserId = count + 1;

        // 3. Insert with new user_id
        await pool.query('INSERT INTO User (user_id, user_name, user_email) VALUES (?, ?, ?)', [newUserId, name, email]);

        res.redirect('/login');
    } catch (err) {
        console.error('Registration Error:', err);
        res.status(500).send('Registration failed');
    }
});


// Handle login
app.post('/login', async (req, res) => {
    const { email } = req.body;
    const [user] = await pool.query('SELECT * FROM User WHERE user_email = ?', [email]);
    if (user.length > 0) {
        req.session.user = user[0];
        res.redirect('/dashboard');
    } else {
        res.send(`<script>alert('User not found!'); window.location.href='/login';</script>`);
        // res.redirect('/login');
    }
});

// Middleware to check login
function auth(req, res, next) {
    if (!req.session.user) return res.redirect('/login');
    next();
}

// Dashboard route
app.get('/dashboard', auth, async (req, res) => {
    const [dashboard] = await pool.query('SELECT * FROM Dashboard WHERE user_id = ?', [req.session.user.user_id]);
    res.render('dashboard', { user: req.session.user, dashboard });
});

// Skills route
app.get('/skills', auth, async (req, res) => {
    const [skills] = await pool.query('SELECT * FROM Skills WHERE user_id = ?', [req.session.user.user_id]);
    res.render('skills', { skills });
});

// Handle adding a new skill
app.post('/skills', auth, async (req, res) => {
    const { skill_name } = req.body;
    try {
        // Insert the new skill into the database
        await pool.query('INSERT INTO Skills (user_id, skill_name) VALUES (?, ?)', 
            [req.session.user.user_id, skill_name]);
        res.redirect('/skills'); // Redirect back to the skills page
    } catch (err) {
        console.error('Error adding skill:', err);
        res.status(500).send('Error adding skill');
    }
});


// Display the form to edit a skill
app.get('/skills/edit/:id', auth, async (req, res) => {
    const skillId = req.params.id;
    const [skill] = await pool.query('SELECT * FROM Skills WHERE skill_id = ? AND user_id = ?', 
        [skillId, req.session.user.user_id]);
    if (skill.length > 0) {
        res.render('editSkill', { skill: skill[0] });
    } else {
        res.status(404).send('Skill not found');
    }
});


// Handle the form submission to update the skill
app.post('/skills/edit/:id', auth, async (req, res) => {
    const skillId = req.params.id;
    const { skill_name } = req.body;
    try {
        // Update the skill in the database
        await pool.query('UPDATE Skills SET skill_name = ? WHERE skill_id = ? AND user_id = ?', 
            [skill_name, skillId, req.session.user.user_id]);
        res.redirect('/skills'); // Redirect back to the skills page
    } catch (err) {
        console.error('Error updating skill:', err);
        res.status(500).send('Error updating skill');
    }
});


// Handle deleting a skill
app.get('/skills/delete/:id', auth, async (req, res) => {
    const skillId = req.params.id;
    try {
        // Delete the skill from the database
        await pool.query('DELETE FROM Skills WHERE skill_id = ? AND user_id = ?', 
            [skillId, req.session.user.user_id]);
        res.redirect('/skills'); // Redirect back to the skills page
    } catch (err) {
        console.error('Error deleting skill:', err);
        res.status(500).send('Error deleting skill');
    }
});



// Learning paths
app.get('/learning-paths', auth, async (req, res) => {
    const [paths] = await pool.query(`
        SELECT LearningPath.* FROM LearningPath
        JOIN Skills ON LearningPath.skill_id = Skills.skill_id
        WHERE Skills.user_id = ?`, [req.session.user.user_id]);
    res.render('learningPaths', { paths });
});

// Gives route
app.get('/gives', auth, async (req, res) => {
    const [gives] = await pool.query(`
        SELECT Skills.skill_name, Gives.day
        FROM Gives
        JOIN Skills ON Gives.skill_id = Skills.skill_id
        WHERE Gives.user_id = ?`, [req.session.user.user_id]);
    res.render('gives', { gives });
});

// Recommended route
app.get('/recommended', auth, async (req, res) => {
    const [recommended] = await pool.query(`
        SELECT Skills.skill_name, LearningPath.description, Recommended.day
        FROM Recommended
        JOIN Skills ON Recommended.skill_id = Skills.skill_id
        JOIN LearningPath ON Recommended.path_id = LearningPath.path_id
        WHERE Skills.user_id = ?`, [req.session.user.user_id]);
    res.render('recommended', { recommended });
});

// Retrieve route
app.get('/retrieve', auth, async (req, res) => {
    const [retrieve] = await pool.query(`
        SELECT Dashboard.completed_paths_names, Retrieve.day
        FROM Retrieve
        JOIN Dashboard ON Retrieve.dashboard_id = Dashboard.dashboard_id
        WHERE Dashboard.user_id = ?`, [req.session.user.user_id]);
    res.render('retrieve', { retrieve });
});

// Logout
app.get('/logout', (req, res) => {
    req.session.destroy(() => {
        res.redirect('/login');
    });
});

app.get('/', (req, res) => {
    res.redirect('/login');
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));
